This repo holds/serves the small data files that
`superset load_examples` uses to load the example data into user
databases.
